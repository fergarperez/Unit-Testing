"use strict";

function uts() {
    let fails = 0;
    let i = 1;
    let pass;
    console.log("testNum | Pass/Fail | score | machineActive [| expectedResponse" + 
        " | response]");
    console.log("---");
    function resultTest(testNum, score, machineActive , expectedResult = getResponse(score, machineActive), 
        response = getResponse(score, machineActive)) {
            if(machineActive) {
                if(typeof score !== "string") { 
                    if(response === expectedResult) {
                        pass = "Pass";
                        if(score > 100 || score < 0) {
                            pass = "Fail"; fails++;
                        }
                    } else {
                        pass = "Fail"; fails++;
                    }
            } else {
                pass = "Fail";
                fails++;
            }
        } else {
            pass = "Fail"; fails++;
        }
            
            console.log(`${testNum} | ${pass} | ${score} | ${machineActive} | ${expectedResult} | ${response}`);
        }
    resultTest(i++, 75, true);
    resultTest(i++, 75, true);
    resultTest(i++, 150, true);
    resultTest(i++, 34, true);
    resultTest(i++, -1, false);
    console.log("---")
    console.log("Fails: " + fails);
}